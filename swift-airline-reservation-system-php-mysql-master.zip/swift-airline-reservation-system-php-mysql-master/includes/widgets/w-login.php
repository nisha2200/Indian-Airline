 <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="download">Passenger Login <span class="caret"></span></a>
              <ul class="dropdown-menu" aria-labelledby="download">
                <li><a href="flogin.php">Login</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>