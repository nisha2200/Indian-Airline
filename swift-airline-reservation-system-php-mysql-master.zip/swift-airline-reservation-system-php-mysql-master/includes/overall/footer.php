		</div>

    <?php include $_SERVER["DOCUMENT_ROOT"].'/swift/includes/footer.php';  
    ?> 
        
    </body>

</html>