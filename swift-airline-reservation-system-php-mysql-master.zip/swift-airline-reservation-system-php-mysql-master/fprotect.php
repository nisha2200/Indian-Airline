<?php 
	include 'core/init.php';
	use_protect_page();
	include 'includes/overall/header.php';
?>
            
            <h1><center>Sorry, only users can view this page!</center></h1>
            

<?php include 'includes/overall/footer.php' ?>        