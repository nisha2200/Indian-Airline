# Flight-booking-Website
This website powered by PHP, HTML ,CSS, JavaScript, and MySql.

This website has its own database which allow the user to signup and login, then book thier own flight.


![1](https://user-images.githubusercontent.com/32971941/64737077-567e5100-d4ec-11e9-8052-659bc1beae8c.PNG)


![2](https://user-images.githubusercontent.com/32971941/64737078-5716e780-d4ec-11e9-8325-6923b4cd5685.PNG)


![3](https://user-images.githubusercontent.com/32971941/64737079-5716e780-d4ec-11e9-9fa0-5ecb94e743b5.PNG)


![4](https://user-images.githubusercontent.com/32971941/64737080-5716e780-d4ec-11e9-9ea6-3281349f8f38.PNG)


![5](https://user-images.githubusercontent.com/32971941/64737076-567e5100-d4ec-11e9-95a8-d0ba2a8cdd6c.PNG)

